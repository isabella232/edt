//>>built
define(
//begin v1.x content
({
		previousMessage: "الاختيارات السابقة",
		nextMessage: "مزيد من الاختيارات"
})
//end v1.x content
);
