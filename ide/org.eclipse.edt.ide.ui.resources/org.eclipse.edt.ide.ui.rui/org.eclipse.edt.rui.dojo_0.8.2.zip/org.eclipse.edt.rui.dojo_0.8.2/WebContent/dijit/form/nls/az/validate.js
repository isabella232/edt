//>>built
define(
//begin v1.x content
({
	"rangeMessage" : "Bu dəyər aralıq xaricində.",
	"invalidMessage" : "Girilən dəyər keçərli deyil.",
	"missingMessage" : "Bu deyər lazımlı."
})
//end v1.x content
);
