//>>built
define(
//begin v1.x content
({
		previousMessage: "이전 선택사항",
		nextMessage: "기타 선택사항"
})
//end v1.x content
);
