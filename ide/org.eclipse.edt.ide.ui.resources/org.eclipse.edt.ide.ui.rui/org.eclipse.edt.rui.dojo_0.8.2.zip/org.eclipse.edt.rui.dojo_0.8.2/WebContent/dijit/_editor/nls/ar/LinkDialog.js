//>>built
define(
//begin v1.x content
({
	createLinkTitle: "خصائص الوصلة",
	insertImageTitle: "خصائص الصورة",
	url: "‏عنوان URL:‏",
	text: "الوصف:",
	target: "الهدف:",
	set: "تحديد",
	currentWindow: "النافذة الحالية",
	parentWindow: "النافذة الرئيسية",
	topWindow: "النافذة العلوية",
	newWindow: "‏نافذة جديدة‏"
})

//end v1.x content
);
