//>>built
define(
//begin v1.x content
({
	createLinkTitle: "Proprietà collegamento",
	insertImageTitle: "Proprietà immagine",
	url: "URL:",
	text: "Descrizione:",
	target: "Destinazione:",
	set: "Imposta",
	currentWindow: "Finestra corrente",
	parentWindow: "Finestra parent",
	topWindow: "Finestra in primo piano",
	newWindow: "Nuova finestra"
})

//end v1.x content
);
