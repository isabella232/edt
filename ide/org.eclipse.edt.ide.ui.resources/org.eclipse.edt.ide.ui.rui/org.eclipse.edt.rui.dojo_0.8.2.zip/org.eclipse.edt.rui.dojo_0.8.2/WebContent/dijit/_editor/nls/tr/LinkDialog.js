//>>built
define(
//begin v1.x content
({
	createLinkTitle: "Bağlantı Özellikleri",
	insertImageTitle: "Resim Özellikleri",
	url: "URL:",
	text: "Açıklama:",
	target: "Hedef:",
	set: "Ayarla",
	currentWindow: "Geçerli Pencere",
	parentWindow: "Üst Pencere",
	topWindow: "En Üst Pencere",
	newWindow: "Yeni Pencere"
})

//end v1.x content
);
