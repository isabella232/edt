//>>built
define(
//begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Cancelar",
	buttonSave: "Guardar",
	itemClose: "Fechar"
})
//end v1.x content
);
